# Third-party notices

Workshop's save reader, editor, Mac shell, installer, and updater are independent implementations. No third-party editor executable is bundled.

`catalog.json` contains factual game item names and internal asset identifiers obtained from the game-data tables published by Steffen André Langnes (SteffenL), as made available in the `data/inventory` directory of [Fristet/Dead-Island-2-Save-Editor-GUI](https://github.com/Fristet/Dead-Island-2-Save-Editor-GUI), version 0.10.0. It contains selected factual fields rather than that project's GUI code. Additional identifiers are read locally from the user's opened save.

The catalog is not guaranteed to cover every game version or DLC release. Game names, trademarks, and asset identifiers belong to their respective owners. Workshop is not affiliated with the game publisher, Save Wizard, SteffenL, or Fristet.

No broad license grant for third-party game data is asserted. This repository currently has no project-wide open-source license chosen by its owner; repository visibility and source access alone are not a license grant.

Perk effect summaries are short paraphrases of in-game descriptions transcribed at the [Dead Island Wiki](https://deadisland.fandom.com/wiki/Perks), with per-entry source URLs in `catalog.json`. Mod-family summaries describe standard elemental or physical effects. Entries whose effects are inferred from internal asset names, and entries with no verified effect, are labeled accordingly. No numerical bonuses or stacking guarantees are asserted.

The weapon silhouettes in `index.html` are original schematic SVG illustrations created for Workshop. They represent weapon families and are not extracted game artwork. Type labels are derived from game model names/identifiers and intentionally fall back to an unverified type where no specific family is established.

The Windows desktop shell uses [pywebview](https://github.com/r0x0r/pywebview) (BSD-3-Clause), pythonnet and its dependencies, and the Python runtime. The Windows executable is built with PyInstaller under its redistribution exception. Dependency package metadata and the Python license accompany the packaged build. Microsoft Edge WebView2 Runtime is a separately installed Microsoft component. The Windows icon is converted from the same original Workshop icon used on Mac.
